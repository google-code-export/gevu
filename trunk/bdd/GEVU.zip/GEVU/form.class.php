<?php

/**
 * Ce fichier contient la classe Form_%class%_%action%.
 *
 * @copyright  2008 Gabriel Malkas
 * @license    "New" BSD License
*/

/**
 * %action% une entrée %class%.
 *
 * @copyright  2008 Gabriel Malkas
 * @license    "New" BSD License
 */
class Form_%class%_%action%
{
           
    public function init()
    {
        
        %elements%
        
        $this->addElements(array(%elements_list%));             
   
    }
            
}