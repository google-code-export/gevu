	array("titre"=>"%column%","champ"=>"%column%","visible"=>true),
    