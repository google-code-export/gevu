$%name% = new Zend_Form_Element_%element%('%name%');
        $%name%->setRequired(%required%)
            ->addValidators(array(%validators%));
        
        